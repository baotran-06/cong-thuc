const recipes = [
  {
    id: "matcha-latte",
    category: "MATCHA",
    title: "MATCHA LATTE",
    lines: [
      "30ml sữa đặc",
      "100ml sữa tươi",
      "10ml rít lùn",
      "3gr matcha",
      "30ml nước sôi"
    ]
  },
  {
    id: "matcha-dau",
    category: "MATCHA",
    title: "MATCHA DÂU ( xoài , đào , việt quất tương tự )",
    lines: [
      "40ml mứt dâu",
      "30ml sữa đặc",
      "10ml rít lùn",
      "100ml sữa tươi",
      "3gr matcha"
    ]
  },
  {
    id: "coconut-matcha",
    category: "MATCHA",
    title: "COCONUT MATCHA",
    lines: [
      "200ml nước dừa tươi",
      "30ml đường",
      "( 40ml rít lùn , 20ml sữa đặc ,",
      "20ml sữa tươi , 3gr matcha , đánh lên , rót lên mặt"
    ]
  },
  {
    id: "matcha-oro",
    category: "MATCHA",
    title: "MATCHA ORO KEM MUỐI",
    lines: [
      "2 bánh oreo nhuyễn",
      "30ml sữa đặc",
      "100ml sữa tươi",
      "10ml rít lùn",
      "(3gr matcha , 30ml nước sôi đánh lên)",
      "Kem muối , ít bánh vụn"
    ]
  },
  {
    id: "matcha-da-xay",
    category: "MATCHA",
    title: "MATCHA ĐÁ XAY (khoai môn , dâu, việt quất )",
    lines: [
      "50gr matcha (cacao 10gr , khoai môn 20gr , dâu , việt quất 40ml)",
      "50ml sữa tươi",
      "20ml nước đường",
      "40ml sữa đặc",
      "20gr bột frap",
      "200gr đá",
      "Matcha"
    ]
  },
  {
    id: "cacao-latte",
    category: "CACAO",
    title: "CACAO LATTE ( cacao kem muối , phô mai , thêm lớp kem )",
    lines: [
      "30ml sữa đặc",
      "100ml sữa tươi",
      "10ml rít lùn",
      "8gr cacao",
      "40ml sước sôi"
    ]
  },
  {
    id: "cacao-oreo",
    category: "CACAO",
    title: "CACAO OREO KEM MUỐI",
    lines: [
      "2 bánh oreo",
      "30ml sữa đặc",
      "100ml sữa tươi",
      "10ml rít lùn",
      "8gr cacao , 40ml nước sôi",
      "Lớp kem , bánh oreo vụn"
    ]
  },
  {
    id: "khoai-mon-latte",
    category: "KHOAI MÔN",
    title: "KHOAI MÔN LATTE ( khoai môn kem muối , phô mai thêm lớp kem)",
    lines: [
      "30ml sữa đặc",
      "100ml sữa tươi",
      "10ml rít lùn",
      "10gr bột khoai môn",
      "40ml nước sôi"
    ]
  },
  {
    id: "khoai-mon-matcha",
    category: "KHOAI MÔN",
    title: "KHOAI MÔN MATCHA",
    lines: [
      "10gr khoai môn , 40ml nước sôi",
      "(30ml sữa đặc,100ml sữa tươi",
      ",10ml rít lùn đánh ly riêng)",
      "3gr matcha ,40ml nước sôi",
      "( đánh khoai môn , đá , rót hỗn hợp sữa , rót matcha )"
    ]
  },
  {
    id: "sinh-to-dau",
    category: "SINH TỐ",
    title: "SINH TỐ DÂU",
    lines: [
      "120gr dâu tây",
      "50ml sữa đặc",
      "30ml sữa tươi",
      "20ml nước đường",
      "10gr bột frap đá xay",
      "200gr đá"
    ]
  },
  {
    id: "sinh-to-bo",
    category: "SINH TỐ",
    title: "SINH TỐ BƠ",
    lines: [
      "1 trái bơ",
      "40ml sữa",
      "50ml sữa tươi",
      "2 muỗng lửng bột frap"
    ]
  },
  {
    id: "tra-dao",
    category: "TRÀ",
    title: "TRÀ ĐÀO",
    lines: [
      "120ml trà đào",
      "30ml mứt đào",
      "40ml Đường",
      "2tr tắc"
    ]
  },
  {
    id: "tra-vai",
    category: "TRÀ",
    title: "TRÀ VẢI",
    lines: [
      "120ml cốt trà lài",
      "15ml syrup vải",
      "30ml đường",
      "2 trái tắc",
      "3 trái vải"
    ]
  },
  {
    id: "tra-tac-thai-xanh",
    category: "TRÀ",
    title: "TRÀ TẮC THÁI XANH",
    lines: [
      "120 trà",
      "40ml đường",
      "2 trái tắc ( có trân châu trắng kèm)"
    ]
  },
  {
    id: "tra-luu-thach-dua",
    category: "TRÀ",
    title: "TRÀ LỰU THẠCH DỪA",
    lines: [
      "120ml trà lài",
      "20ml đường",
      "40ml syrup lựu",
      "1 vá thạch dừa"
    ]
  },
  {
    id: "tra-dao-chanh-day",
    category: "TRÀ",
    title: "TRÀ ĐÀO CHANH DÂY",
    lines: [
      "120ml cốt trà đào",
      "50ml chanh dây",
      "30ml nước đường",
      "30ml mứt đào",
      "2 trái tắc"
    ]
  },
  {
    id: "tra-sen-vang",
    category: "TRÀ",
    title: "TRÀ SEN VÀNG",
    lines: [
      "120ml cốt trà olong",
      "20ml nước đường",
      "1 vá sen + nước ngâm sen",
      "Lớp kem"
    ]
  },
  {
    id: "tra-sen-hat-de",
    category: "TRÀ",
    title: "TRÀ SEN HẠT DẺ",
    lines: [
      "120ml cốt trà olong",
      "1 vá sen + nước ngâm sen",
      "20ml đường",
      "Kem hạt dẻ ("
    ]
  },
  {
    id: "tra-sua-thai-xanh",
    category: "TRÀ",
    title: "TRÀ SỮA THÁI XANH ( thái đỏ , khoai môn, hồng trà sữa tương tự )",
    lines: [
      "150ml trà sữa",
      "Trân châu đen"
    ]
  },
  {
    id: "sua-chua-lac",
    category: "SỮA CHUA",
    title: "SỮA CHUA lắc",
    lines: [
      "40ml mứt",
      "1 hủ sữa chua",
      "2 trái tắc",
      "30ml sữa đặc",
      "50ml sữa tươi",
      "(Sấy thăng hoa thì thêm Kem , trái cây sấy)"
    ]
  }
];

const categoryInfo = [
  ["MATCHA", "🍵"],
  ["CACAO", "🍫"],
  ["KHOAI MÔN", "🥔"],
  ["TRÀ", "🍑"],
  ["SINH TỐ", "🥤"],
  ["ĐÁ XAY", "🧊"],
  ["SỮA CHUA", "🥛"]
];

const categoriesEl = document.getElementById("categories");
const recipesEl = document.getElementById("recipes");
const currentTitleEl = document.getElementById("currentTitle");
const countEl = document.getElementById("recipeCount");
const searchInput = document.getElementById("searchInput");
const emptyEl = document.getElementById("empty");
const showAllBtn = document.getElementById("showAll");

const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const modalCategory = document.getElementById("modalCategory");
const modalRecipe = document.getElementById("modalRecipe");
const similarEl = document.getElementById("similar");

let selectedCategory = "TẤT CẢ";

function categoryForRecipe(recipe) {
  if (recipe.category === "MATCHA" && recipe.title.includes("ĐÁ XAY")) return "ĐÁ XAY";
  return recipe.category;
}

function renderCategories() {
  categoriesEl.innerHTML = categoryInfo.map(([name, icon]) => `
    <button class="category ${selectedCategory === name ? "active" : ""}" data-category="${name}">
      <span class="icon">${icon}</span>
      <strong>${name}</strong>
    </button>
  `).join("");

  document.querySelectorAll(".category").forEach(btn => {
    btn.addEventListener("click", () => {
      selectedCategory = btn.dataset.category;
      searchInput.value = "";
      render();
    });
  });

  showAllBtn.classList.toggle("active", selectedCategory === "TẤT CẢ");
}

function getFilteredRecipes() {
  const keyword = searchInput.value.trim().toLowerCase();

  return recipes.filter(recipe => {
    const categoryMatch =
      selectedCategory === "TẤT CẢ" || categoryForRecipe(recipe) === selectedCategory;

    const text = [recipe.title, recipe.category, ...recipe.lines].join(" ").toLowerCase();
    const searchMatch = !keyword || text.includes(keyword);

    return categoryMatch && searchMatch;
  });
}

function render() {
  renderCategories();

  const filtered = getFilteredRecipes();

  currentTitleEl.textContent = selectedCategory === "TẤT CẢ"
    ? "Tất cả món"
    : selectedCategory;

  countEl.textContent = `${filtered.length} món`;
  emptyEl.hidden = filtered.length !== 0;

  recipesEl.innerHTML = filtered.map(recipe => `
    <article class="recipe-card" data-id="${recipe.id}">
      <span class="tag">${categoryForRecipe(recipe)}</span>
      <h3>${escapeHtml(recipe.title)}</h3>
      <div class="preview">${escapeHtml(recipe.lines.slice(0, 3).join("\n"))}</div>
    </article>
  `).join("");

  document.querySelectorAll(".recipe-card").forEach(card => {
    card.addEventListener("click", () => openRecipe(card.dataset.id));
  });
}

function openRecipe(id) {
  const recipe = recipes.find(item => item.id === id);
  if (!recipe) return;

  modalCategory.textContent = categoryForRecipe(recipe);
  modalTitle.textContent = recipe.title;

  modalRecipe.innerHTML = recipe.lines.map(line => `
    <p class="recipe-line ${line.startsWith("(") ? "parenthetical" : ""}">
      ${escapeHtml(line)}
    </p>
  `).join("");

  const sameGroup = recipes.filter(item =>
    item.id !== recipe.id && categoryForRecipe(item) === categoryForRecipe(recipe)
  ).slice(0, 8);

  similarEl.innerHTML = sameGroup.length ? `
    <h3>Món cùng nhóm</h3>
    <div class="similar-list">
      ${sameGroup.map(item => `
        <button data-similar="${item.id}">${escapeHtml(item.title)}</button>
      `).join("")}
    </div>
  ` : "";

  similarEl.querySelectorAll("[data-similar]").forEach(btn => {
    btn.addEventListener("click", () => openRecipe(btn.dataset.similar));
  });

  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

searchInput.addEventListener("input", () => {
  selectedCategory = "TẤT CẢ";
  render();
});

showAllBtn.addEventListener("click", () => {
  selectedCategory = "TẤT CẢ";
  searchInput.value = "";
  render();
});

document.getElementById("closeModal").addEventListener("click", closeModal);
document.getElementById("modalBackdrop").addEventListener("click", closeModal);

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeModal();
});

render();
